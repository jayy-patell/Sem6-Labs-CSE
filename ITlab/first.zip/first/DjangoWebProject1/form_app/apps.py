from django.apps import AppConfig


class form_appConfig(AppConfig):
    name = 'form_app'

from django.apps import AppConfig


class q2Config(AppConfig):
    name = 'q2'

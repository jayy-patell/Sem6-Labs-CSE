from django.shortcuts import render

# Create your views here.

def q2(request): 
    return render(request, 'WebPage2.html')
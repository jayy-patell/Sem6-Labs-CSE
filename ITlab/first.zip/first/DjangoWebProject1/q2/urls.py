from  django.conf.urls import url 
from . import views 

urlpatterns = [ 
    url('', views.q2, name='q2'), 
] 